import unittest
from huffman import*

class MyTestCase(unittest.TestCase):
    def test_huffman_code(self):
        self.assertEqual(huffman_code('test3', 'output0_compressed.txt'), str(11011011000011011010011010011))


    if __name__  == '__main__'  :
        unittest.main()