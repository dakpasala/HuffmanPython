with open("dak.txt", "w") as file:
    file_txt = []
    for x in range(97):
        file_txt.append('')
    file_txt.append('1108')
    file_txt.append('101')
    file_txt.append('111')
    file_txt.append('0')
    file_txt.append('1101')
    for x in range(8):
        file_txt.append('')
    file_txt.append('100')
    for x in range(144):
        file_txt.append('')
    print(len(file_txt))
    file.write(str(file_txt))