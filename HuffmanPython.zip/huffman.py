import huffman_bit_writer

class Node:
    def __init__(self, char=None, freq = 0, left = None, right=None):
        self.char = char
        self.freq = freq
        self.left = left
        self.right = right

def cnt_freq(filename):
    freq = [0] * 256

    with open(filename, 'r') as file:
        contents = file.read()
        for char in contents:
            freq[ord(char)] += 1

    return freq

def create_huff_tree(freq):
    nodes = [Node(chr(i), freq[i]) for i in range(256) if freq[i] > 0]
    while len(nodes) > 1:
        nodes = sorted(nodes, key = lambda x: x.freq)
        left = nodes.pop(0)
        right = nodes.pop(0)
        parent = Node(freq= left.freq + right.freq, left = left, right = right)
        nodes.append(parent)
    return nodes[0]

def huffman_code(in_file, out_file):
    freq = cnt_freq(in_file)

    root = create_huff_tree(freq)

    code_dict = {}

    def traverse(node, code = ''):
        if node.char:
            code_dict[node.char] = code
        else:
            traverse(node.left, code + '0')
            traverse(node.right, code + '1')
    traverse(root)



    with open(in_file, 'r') as in_file, open (out_file, 'a') as out_file:
        contents = in_file.read()
        encoded = ''.join([code_dict[char] for char in contents])
        out_file.write(encoded)
    return encoded

def create_code(root_node):
    code_arr = [''] * 256

    def traverse(node, code = ''):
        if node.char:
            code_arr[ord(node.char)] = code
        else:
            traverse(node.left, code + '0')
            traverse(node.right, code + '1')

    traverse(root_node)
    return code_arr

def create_header(list_of_freqs):
    numstring = ''
    for i in range (len(list_of_freqs)):
        if list_of_freqs[i] != 0:
            numstring = numstring + (str(i) + ' ' + str(list_of_freqs[i]) + ' ')
    numstring = numstring [:-1]
    return numstring


 #numstring = print(create_code(create_huff_tree(cnt_freq('test'))))
#code = huffman_encode('test3', 'output.txt')
#print(create_huff_tree(cnt_freq('test2')))
#header = create_header(cnt_freq('test3'))

def huffman_encode(in_file, out_file):
    frequencies = cnt_freq(in_file)
    header = create_header(cnt_freq(in_file))
    code = huffman_code(in_file, out_file)
    print(frequencies)
    print(header)
    print(code)
    Hobject = huffman_bit_writer.HuffmanBitWriter(out_file)
    huffman_bit_writer.HuffmanBitWriter.write_str(Hobject, header)
    huffman_bit_writer.HuffmanBitWriter.write_code(Hobject, code)
    huffman_bit_writer.HuffmanBitWriter.close(Hobject)
    return header, code

huffman_encode('test3', 'output0_compressed.txt')